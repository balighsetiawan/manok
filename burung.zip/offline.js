﻿{
	"version": 1709175445,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/backgroundmanok-sheet0.png",
		"images/manok-sheet0.png",
		"images/manok-sheet1.png",
		"images/tiang__1_removebgpreview-sheet0.png",
		"images/tiang__2_removebgpreview-sheet0.png",
		"images/sprite-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}